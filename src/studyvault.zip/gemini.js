const API_KEY ="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";

async function askAI(prompt) {

  try {

    const response = await fetch(

      "https://api.groq.com/openai/v1/chat/completions",

      {

        method: "POST",

        headers: {

          "Content-Type":
            "application/json",

          Authorization:
            `Bearer ${API_KEY}`,

        },

        body: JSON.stringify({

          model:
            "llama-3.1-8b-instant",

          messages: [

            {
              role: "user",
              content: prompt,
            },

          ],

        }),

      }

    );

    const data =
      await response.json();

    console.log(data);

    if (data.error) {

      return data.error.message;

    }

    return data
      .choices[0]
      .message
      .content;

  } catch (error) {

    console.log(error);

    return "AI failed 😭";

  }

}

export default askAI;